package fsdd.dungeons_and_dragons;
import java.util.ArrayList;
/**
 * Models a bag of items carried by a hero.
 * @author Simon Powers
 *
 */
public class Bag {

		//instance variables go here
		private ArrayList<Item> bag; //Stores a list of items a hero is carrying.
		
		//constructor goes here
		/**
		 * Creates an empty bag.
		 */
		public Bag(){
			bag = new ArrayList<>();
		}
		
		//methods to implement queries and commands go below here
		//TODO: add Javadoc comments to every method below here.
		
		public void addItem(Item item){
			//Write code here to add an item to the bag.
			
		}
		
		public void removeItem(Item item){
			//Write code here to remove an item from the bag.
		}
		
	
		public int getWeight(){
			//Change the code in this method to calculate the total weight
			//of all items in the bad and return it.
			return 0;
		}
		
		public String toString(){
			//Change the code below to return a String detailing every item
			//in the bag.
			return "";
		}
		
		public Item getItem(int index){
			//Change the code below to get the item at position index.
			return null;
		}
		
		public int getNumberOfItems(){
			//Change the code below to return the number of items in the bag.
			return 0;
		}
		
		
		
}
