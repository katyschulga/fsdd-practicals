/**
 * 
 */
package fsdd.dungeons_and_dragons;

/**
 * A class to model a scroll.
 * @author Simon Powers
 *
 */
public class Scroll extends Item {
	
	
	
	/**
	 * Creates a new scroll.
	 * @param name		the name of the scroll
	 * @param isCursed	whether the scroll is cursed or not
	 * @param weight	the weight of the scroll
	 * 
	 */
	public Scroll(String name, boolean isCursed, int weight ){
		/* Note the call to the constructor of the superclass.
		 * This sets up the Item inside the Scroll.
		 */
		super(name, isCursed, weight);
	}

	/* 
	 * Non-Javadoc because the method is inherited but being overridden.
	 * 
	 * Implements the command to use a scroll.
	 */
	@Override
	public void use() {
		System.out.println("Reading the scroll outloud");

	}

}
