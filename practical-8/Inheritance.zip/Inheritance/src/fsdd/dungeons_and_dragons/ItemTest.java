package fsdd.dungeons_and_dragons;

/**
 * A class to create and test our items and bag.
 * @author Simon Powers
 *
 */
public class ItemTest {


	public static void main(String[] args) {
		Bag backpack = new Bag();
		Ring ring1 = new Ring("Ring of fire", true, 20);
		backpack.addItem(ring1);
		Ring ring2 = new Ring("Ring of ice", false, 10);
		backpack.addItem(ring2);
		Scroll scroll1 = new Scroll("Scroll of Mordor", true, 200);
		backpack.addItem(scroll1);
		Scroll scroll2 = new Scroll("Scroll of Lothlorien", false, 1);
		backpack.addItem(scroll2);
		
		System.out.println("The contents of the hero's backpack are: ");
		System.out.println(backpack);
		
		System.out.println("The weight of the hero's backpack is: " + backpack.getWeight());
		//remove the ring of fire
		backpack.removeItem(ring1);
		System.out.println("The new weight of the hero's backpack is: " + backpack.getWeight());
		
		/*after you have implemented the getItem(index) method in Bag,
		*uncomment out the code below and run it to see polymorphism
		*in action.
		*/
		
//		Item fromBag;
//		for(int i=0; i<backpack.getNumberOfItems(); i++){
//			fromBag = backpack.getItem(i);
//			fromBag.use();
//		}
		
		
		

	}

}
