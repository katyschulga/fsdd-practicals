package fsdd.dungeons_and_dragons;

/**
 * An abstract class to model an item in Dungeons and Dragons.
 * @author Simon Powers
 */
public abstract class Item {
	
	/*TODO: add instance variable definitions below here
	 * You will need one instance variable to store each of the three
	 * properties name, cursed, and weight.
	 */
	
	
	
	//TODO: implement the following constructor 
	/**
	 * @param name		the name of the item
	 * @param isCursed	whether the item is cursed or not
	 * @param weight	the weight of the item
	 */
	public Item(String name, boolean isCursed, int weight){
		//Add code here to assign these parameters to the instance variables.
		
	}
	 
	
	//TODO: implement the following four queries by writing correct code between the {}s.
	
	/**
	 * Query to determine whether the item is cursed or not.
	 * @return	true if the item is cursed
	 */
	public boolean isCursed(){
		//Change this code to return true if and only if the item is cursed.
		return false;
	}
	
	/**
	 * Queries the item for its name.
	 * @return	the name of the item
	 */
	public String getName(){
		//Change this code to return the item's name.
		return "";
		
	}
	
	/**
	 * Queries the item for its weight.
	 * @return	the weight of the item
	 */
	public int getWeight(){
		//Change this code to return the weight of the item.
		return 0;
	}
	

	/*TODO: write the toString() method to return a String
	 * representing the item's name, weight, and whether it is cursed or not.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		//Change this code to return a String giving the item's name, whether it is
		//cursed, and its weight.
		return "";
	}
	
	/**
	 * Command to use the item.
	 * 
	 */
	public abstract void use(); //we supply implementations in the subclasses.
		
	
	
	
	

}
