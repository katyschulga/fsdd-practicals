/**
 * 
 */
package fsdd.dungeons_and_dragons;

/**
 * A class to model a ring.
 * @author Simon Powers
 *
 */
public class Ring extends Item {
	
	/**
	 * Creates a new ring.
	 * @param name		the name of the ring
	 * @param isCursed	true if the item is cursed
	 * @param weight	the weight of the scroll
	 */
	public Ring(String name, boolean isCursed, int weight ){
		/* Note the call to the constructor of the superclass.
		 * This sets up the Item inside the Scroll.
		 */
		super(name, isCursed, weight);	
		
	}
	
	/* 
	 * Non-Javadoc because the method is inherited but being overridden.
	 * 
	 * Implements the command to use a ring.
	 */
	@Override
	public void use(){
		System.out.println("Using the ring to heal a hero.");
	}

}
