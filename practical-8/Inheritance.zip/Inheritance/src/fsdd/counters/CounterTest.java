package fsdd.counters;
/**
 * A class to test our counters.
 * @author Simon Powers
 *
 */
public class CounterTest {

	public static void main(String[] args) {
		
		//when you have implemented NormalCounter and DoubleCounter, uncomment
		//out the two lines below.
		
		//Counter normalCounter = new NormalCounter();
		//Counter doubleCounter = new DoubleCounter();
		
		//TODO: write code below here to increment both counters 25 times,
		//then print out their counts. Note the polymorphism.
		

	}

}
