package fsdd.counters;

/**
 * A class to model a generic counter.
 * @author Simon Powers
 *
 */
public abstract class Counter {
	
	private int count;
	
	/**
	 * @param initialCount	the initial count
	 */
	public Counter(int initialCount){
		this.count = initialCount;
	}
	
	/**
	 * Command to increment the counter.
	 */
	public abstract void increment();
	
	
	/**
	 * Command to decrement the counter.
	 */
	public abstract void decrement();
	
	
	/**
	 * Query to get the count.
	 * @return	the current count
	 */
	public int getCount(){
		return this.count;
	}

}
